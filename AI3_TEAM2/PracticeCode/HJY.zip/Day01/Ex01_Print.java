package Day01;

public class Ex01_Print {

	public static void main(String[] args) {
		System.out.print("안녕하세요");
		System.out.println("안녕하세요 출력 후 줄바꿈");
		System.out.println("자바 첫 수업");
		System.out.println();
		System.out.println("이어지는 문자열...");
	}
}
