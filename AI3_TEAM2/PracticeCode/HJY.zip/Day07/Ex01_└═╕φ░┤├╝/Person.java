package Day07.Ex01_익명객체;

public class Person {

	String name;
	int age;
	
	void work() {
		System.out.println("일을 합니다.");
	}
}
