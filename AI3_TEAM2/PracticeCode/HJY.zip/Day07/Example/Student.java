package Day07.Example;

public class Student extends Person {

	String major;
	int age = 20;
	
	void work() {
		System.out.println("공부 합니다.");		
	}
}
