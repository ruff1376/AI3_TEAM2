package Day07.Example;

public class Person {

	String name;
	int age = 10;
	
	void work() {
		System.out.println("일을 합니다.");		
	}
}
