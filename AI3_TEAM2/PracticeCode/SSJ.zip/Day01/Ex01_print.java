package Day01;

public class Ex01_print {

	
public static void main(String[] args) {
//	기본 출력 메소드
//	 print(), prinln() 메소드를 호출하여 사용한다.
//	system.out 출력 객체를 사용한다.
//	sysout : ctrl + space
	System.out.print("안녕하세요");
	
	System.out.println("asdasdasd");
	
	System.out.println("안녕하세요 출력 후 줄 바꿈");
	System.out.println("gi");
	System.out.println("자야되는디");
	
}
}
