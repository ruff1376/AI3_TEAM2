package Day_09_Ex01;

public class Person {

	@Override
	public String toString() {
		return "Person [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

}
