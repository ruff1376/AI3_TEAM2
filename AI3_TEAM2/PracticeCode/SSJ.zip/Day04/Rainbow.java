package Day04;

public enum Rainbow {

	
	 RED, ORANGE, YELLOW, GREEN, BLUE, NAVY, PURPLE
	 
}
