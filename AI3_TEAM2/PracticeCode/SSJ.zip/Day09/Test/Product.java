package Day09.Test;

public class Product {

	 String name;
	 int price;
	 
	 //생성자
public Product() {
	
}
//getter,setter
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getPrice() {
	return price;
}

public void setPrice(int price) {
	this.price = price;
}
	 



}
