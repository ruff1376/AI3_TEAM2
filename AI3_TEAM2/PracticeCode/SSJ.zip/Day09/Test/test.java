package Day09.Test;

//패키지 아래 전체 클래스 포함하기 : import 패키지.*;


public class test {

	public static void main(String[] args) {
		Product product = new Product();
		
		Cloth cloth = new Cloth();
		
		Food food = new Food();
		
		
	}
}
