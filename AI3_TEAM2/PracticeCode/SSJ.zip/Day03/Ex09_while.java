package Day03;

public class Ex09_while {
	

	public static void main(String[] args) {
//		1~10까지 공백을 두고 출력하시오.
//		1 2 3 4 5 6 7 8 9 10
	int a = 1;
	
	while ( a <= 10) {
		System.out.println(a++ + " ");
//		a = a + 1;
//	 a += 1;
//	 증감연산자
//	a++;
	}
	}
}
