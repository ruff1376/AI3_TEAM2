/**
 * 
 */
/**
 * 
 */
module java {
	
	//필요한 모듈 설정
	requires static lombok;
	
}