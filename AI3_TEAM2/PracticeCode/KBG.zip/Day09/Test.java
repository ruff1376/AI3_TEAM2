package Day09;


import Day09.test.Cloth;
import Day09.test.Food;
import Day09.test.Product;



import Day09.test.*;
public class Test {

	public static void main(String[] args) {
		Product product = new Product();
		
		Cloth cloth = new Cloth();
		
		Food food = new Food();
		
		
		
	}
}
