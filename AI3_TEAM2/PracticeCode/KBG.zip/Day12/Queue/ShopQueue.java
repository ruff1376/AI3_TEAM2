package Day12.Queue;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Iterator;
/**
 * 큐 자료구조는 실세계에 있는 줄서기와 유사하다
 * 
 * 가게에 방문한 손님들의 웨이팅 관리를하는 프로그램을 만들어 봅니다.
 */

public class ShopQueue {

	private Queue<String> customerQueue = new LinkedList<String>();
	
	//손님대기
	public void wait(String customer) {
		customerQueue.offer(customer);
		System.out.println("대기한 손님 : " + customer);
	}
	
	//손님 입장
	public void serve() {
		if (!customerQueue.isEmpty()) {
		String servedCustomer =  customerQueue.poll();
		System.out.println("입장한 손님 : " + servedCustomer);
	} else {
		System.out.println("대기중인 고객에 없습니다.");
			
		}
		
		
	}
	
	//대기열 입장
	public void showWaitingList() {
		Iterator<String> it = customerQueue.iterator();
		int index = 0;
		while (it.hasNext()) {
			String customer = (String) it.next();
			System.out.println((++index)+ ". " + customer);
			
		}
	}
	public static void main(String[] args) {
		ShopQueue shopQueue = new ShopQueue();
		shopQueue.wait("윤홍민");
		shopQueue.wait("이준영");
		shopQueue.wait("고건우");
		shopQueue.showWaitingList();

		shopQueue.serve();
        shopQueue.wait("신유식");
        
        shopQueue.serve();
        shopQueue.serve();
        
        shopQueue.showWaitingList();;
        shopQueue.serve();        
        shopQueue.serve();
        
	}
}
