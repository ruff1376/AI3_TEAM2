package Day05_상속;

public class Jiwoo {

	public static void main(String[] args) {
		Pikachu pikachu = new Pikachu();
		pikachu.energy = 100;
		pikachu.type = "전기";
		
       
		System.out.println("::::::::::피카츄:::::::::");
		System.out.println("에너지 : " + pikachu.energy);
		System.out.println("타입 : " + pikachu.type);
		System.out.println("공격A : " + pikachu.aAttack());
		System.out.println("공격B : " + pikachu.bAttack());
		System.out.println();
		
		
		
		Pikachu pikachu2 = new Pikachu(159,"진화");
		System.out.println(":::::::피카츄 (LV.20)::::::");
		System.out.println("에너지 : " + pikachu2.energy);
		System.out.println("타입 : " + pikachu2.energy);
		System.out.println("공격A : " + pikachu2.energy);
		System.out.println("공격B : " + pikachu2.energy);
		
		System.out.println();
	}

}
