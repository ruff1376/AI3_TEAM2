package Day02;

public class Ex_05_int {

}
