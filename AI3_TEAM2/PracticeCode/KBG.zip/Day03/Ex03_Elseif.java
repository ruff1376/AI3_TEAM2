package Day03;

import java.util.Scanner;

public class Ex03_Elseif {

	public static void main(String[] args) {
		//성적을 입력 받아서, 성적에 따른 학점 A~F 를 출력하시오.
		Scanner sc = new Scanner(System.in);
		int score = sc.nextInt();
		char grade = 'f';
		
		//if
		//90점 이상.A
		//80점 이상,B
		//70점 이상,C
		//69점 이상,D
		//60점 미만,F
		
		if( score >= 90 && score <= 100 ) System.out.println("A");
		if( score >= 90 && score <= 90 ) System.out.println("B");
		if( score >= 90 && score <= 80 ) System.out.println("C");
		if( score >= 90 && score <= 70 ) System.out.println("D");
		if( score >= 90 && score <= 0 ) System.out.println("E");
		System.out.println(grade);
		
		if( score >= 90 && score <= 100 ) grade = 'A';
		if( score >= 90 && score <= 90 ) grade = 'B';
		if( score >= 90 && score <= 80 ) grade = 'C';
		if( score >= 90 && score <= 70 ) grade = 'D';
		if( score >= 90 && score <= 0 ) grade = 'E';
		System.out.println(grade);
		
		if( score >= 90 && score <= 100 ) grade = 'A';
		else if( score >= 80)   grade = 'B';
		else if( score >= 80)   grade = 'B';
		else if( score >= 80)   grade = 'B';
		else grade = 'F';
		System.out.println("학점 : " + grade);
		
		
		sc.close();
	}
	
}
