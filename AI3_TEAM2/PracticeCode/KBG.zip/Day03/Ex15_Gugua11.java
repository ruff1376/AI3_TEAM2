package Day03;

public class Ex15_Gugua11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // 단에 대한 반복 : 1~9
		//각 단의 곱 : 1~9
		
		//중첩 반복문(이중반복문)
		// 안쪽 반복문이 먼저 다 돌고,바깥쪽반복문의 반복변수가 증감된다.
		for (int i = 1; i <= 9 ; i ++) {
			for (int j = 1; j <= 9 ; j ++) {
			System.out.println(j +"x" + i + "=" + (i*j));
			System.out.println("\t");
			
		}
			System.out.println();
	}
	

}
}