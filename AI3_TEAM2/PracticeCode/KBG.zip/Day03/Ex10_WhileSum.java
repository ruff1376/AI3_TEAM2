package Day03;

public class Ex10_WhileSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        //1qnxj 1000까지 합을 구하시오
		//1+2+3+...+1000 = ?
		
		int a = 1;
		int sum = 0;
		while ( a <= 1000 ) {
		     sum = sum + a;
		     a = a + 1;
		while ( a <= 1000) {
			
			sum += a++;
	      System.out.println(sum);	
	      
			
		}
	}
}
}

