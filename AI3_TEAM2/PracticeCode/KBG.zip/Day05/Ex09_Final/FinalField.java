package Day05.Ex09_Final;

public class FinalField {

	// * 관례
	// : 대문자로 스네이크 케이스 표기법으로 명명하는 것이 관례다.
	
	public static final int MAX_VOLUME = 100; 
	public static final double PI = 100; 
	public static final String DEFAULT_USER = "GUEST";
}
