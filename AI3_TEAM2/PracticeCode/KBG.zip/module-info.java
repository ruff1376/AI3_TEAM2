/**
 * 
 */
/**
 * 
 */
module Java {
	
	//필요 모듈 설정
	requires static lombok;
}


