package Day07.EX02_다중상속;

public interface SmartRemoteControl {

	// 터치패드 기능
		// - x, y 좌표 위치에 터치패드 클릭
		void touch(int x, int y);
	}
