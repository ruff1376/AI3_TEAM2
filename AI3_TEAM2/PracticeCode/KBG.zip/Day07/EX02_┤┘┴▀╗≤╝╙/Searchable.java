package Day07.EX02_다중상속;

public abstract class Searchable {

	// 채널 검색
		// : 검색어에 해당하는 채널번호를 반환
		abstract int channelSearch(String keyword);
		
		// 컨텐츠 검색
		// : 검색어에 해당하는 컨텐츠를 반환
		abstract String[] contentSearch(String keyword);
		
	

}