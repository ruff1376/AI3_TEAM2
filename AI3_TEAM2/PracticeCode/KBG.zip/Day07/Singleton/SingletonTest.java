package Day07.Singleton;

public class SingletonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        //singleton singleton = new singleton();
		
		Singleton s01 = Singleton.getInstance();
		Singleton s02 = Singleton.getInstance();
		
				System.out.print("s01과 02가 같은지 여부: ");
				System.out.println("s01 == s02");
	}

}
