package Day06;

import java.util.Scanner;

public class Ex03_화폐매수 {

	//구매비 :657862
	//5만원짜리:13장
	//만원짜리:0장
	//5천원짜리:1장
	//천원짜리:2장
	//500원짜리:1개
	//100원짜리:3개
	//50원 :1개
	//10원:1개
	//5원:0개
	//1원 : 2개
	//위와 같이 입력하면 큰 화폐단위부터 계산하여 
	//화폐단위별로 화폐매수를 출력 하는 프로그램을 작성하시오.
	
	
	public static void main(String[] args) {
		
		//순서도 : 필요한 변수 선언 
		// 입력 금액 화폐매수 화폐단위
		//구매비 입력
		//화폐매수 계산
		//화폐 매수 = 입력금액/화폐단위
		//잔액계산 657862-(50000*13) = 7862
		//잔액 = 입력금액 - (화폐단위 * 화폐매수)
		//657862 % 50000 = 7862
		//잔액 = 입력금액 % 화폐단위
		//화폐단위 변환
		//5000/5 = 10000
		//10000/2 =5000
		//5000/5 = 1000
		// 100/2 = 500
		
		//번갈아 가면서,/5 ,/2 연산반복
		//화폐 안뒤 = 화폐단위/5
		//화폐단위 = 화폐단위 /2
		
		Scanner sc = new Scanner(System.in);
	System.out.println("구매비: ");
	int input = sc.nextInt();
	int money = 50000;
	int count = 0;
	
	count = input / money;
	input = input - (money * count);
	input = input & money;
	
	money = money /5;
	money = money /2;
	boolean sw = true;
	while( money >= 1 ) {
		count = input / money;
		System.out.println(money + " : " + count + "개");
		
		input = input % money;
		if( sw )
			money = money /5;
		
		else
			money = money/2;
		sw = !sw;
			sc.close();
		}
		
	}
	
		
			
		
		
			
}


