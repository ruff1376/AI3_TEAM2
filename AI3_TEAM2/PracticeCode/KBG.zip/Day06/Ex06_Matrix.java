package Day06;

import java.util.Iterator;
import java.util.Scanner;

public class Ex06_Matrix {

	public static void main(String[] args) {
		//양의 정수 m 과 n을 입력받아 저장하고
		//m 행 n 열의 2차원 배열을 생성한다
		//각 요소의 값을입력받고 그대로 출력하시오
		//예시
		//m:2
		//n:3
		//123
		//456
		//출력예시
		//123
		//456
		Scanner sc = new Scanner(System.in);
		System.out.println("M : ");
		int M = sc.nextInt();
		System.out.println("N : ");
		int N = sc.nextInt();
//m 행 n 열의 2차원 배열 선언 및 생성
		int arr[][] = new int [M][N];
		
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.println();
			}
		}
			for (int i = 0; i < arr.length; i++) {
				for (int j = 0; j < arr.length; j++) {
					System.out.println(arr[i][j] + " ");
					System.out.println();
				}
			}
			System.out.println("-------------");
			for (int[] row : arr) {
				for (int co1 : row ) {
					System.out.println(co1 + " ");
				}
					System.out.println();
		}
		
		
		sc.close();
	}

}
