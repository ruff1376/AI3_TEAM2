package Day08.Ex01_TryCatch;

import java.util.Scanner;
public class DiviedByZero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc= new Scanner(System.in);
		System.out.println("a : ");
		int a = sc.nextInt();
		System.out.println("b: ");
		int b = sc.nextInt();
		
		//어떤수를 0으로 나누는 경우는 수학정으로 정의되지 않아서 예외
		//예외처리 :try~catch
		//trt :  ctrl + space
		try {
			System.out.println("a/b ="+(a/b));
		} catch (ArithmeticException e) {
			// TODO: handle exception
			//예외 발생시 실행할 예외 처리 문장
			//syserr :ctrl + space
			System.err.println("0으로 나누는 연산은 수학적으로 정의되지 않았습니다.");
		}
		finally {
			//예외 발생과 무관하게 실행하는 문장
			// 주로 예외 처리와 관련된 문장을 작성
		}
		System.out.println("메모리를 해제합니다");
		sc.close();
		System.out.println("프로그램을 종료합니다");
		
	}
}
