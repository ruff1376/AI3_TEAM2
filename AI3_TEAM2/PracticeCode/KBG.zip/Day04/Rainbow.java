package Day04;

public enum Rainbow {
	
	RED,ORANGE, TELLOW, GREEN, BLUE, NAVY, PURPLE

}
