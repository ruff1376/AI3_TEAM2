package Day04;

import java.util.Scanner;

public class Ex03_Min {

	public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
	
		
		
		int arr[];
	    arr  = new int[n];
	    
	    for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
	    
	    
	    
	    
	    int min = 0;
	    for (int i = 0; i < arr.length; i++) {
			if(min > arr[i]) {
				
			   min = arr[i];
			}
		}
	    
	    sc.close();
	    
		
		System.out.println();
	
}

	}
	

