package Day04;

import java.util.Scanner;

public class Ex02_Max {
                
	public static void main(String[] args) {
      
		// 첫번째 줄에 입력할 개수 n을 입력받고
		//둘째 줄에 n 개의 정 수를 공백을 두고 입력받으시오.
		// n개의 정수중, 최댓값을 구하시오.
		//(입력)
		//5
		// 90 60 70 100 55
		//(출력)
		//최댓값 : 100
		
		// ( 순서도 )
		//정수 하나를 입력받아서 n에 대입
		// n 개의 요소를 갖는 배열 선언 및 생성
		// n번 반복하면서 정수를 입력받아서 배열 arr에 순서대로 대입한다
		// 배열을 반복해서 최댓값 max를 배열  i 번째 요소랑 비교
		// 두 요소중 더 큰 요소를 max에 대입
		// 반복 끝나고 max를 출력
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		//1
		
		
		int arr[];
	    arr  = new int[n];
	    //2
	    for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}//3
	    //n : 5
	    //i : 0 1 2 3 4
	    
	    
	    
	    int max = 0;
	    for (int i = 0; i < arr.length; i++) {
			if(max < arr[i]) {
				//5
			   max = arr[i];
			}
		}
	    //6
	    sc.close();
	    
		
		System.out.println();
	
}
}