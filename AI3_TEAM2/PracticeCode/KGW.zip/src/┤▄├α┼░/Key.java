package 단축키;
// 주석 : 프로그램에 영향이 없는 메모 (코드 설명, 기록)
// 주석 : ctrl + / , ctrl + shift + C
// 한줄 복사 : ctrl + alt + 위/아래
// 코드 이동 : alt + 위/아래
// 스크롤 이동 : ctrl + 위/아래
// 새 파일 생성 : ctrl + n
// 탭 종료 : ctrl + w
// 전체 탭 종료 : ctrl + shift + w
// 프로그램 실행 : ctrl + f11
// 이름 바꾸기 : f2
// 찾기 바꾸기 : ctrl + f
// 단어 찾기 : ctrl + k
// 파일 찾기 : ctrl + shift + r
// 코드 찾기 : ctrl + h
// 퀵 서치 : ctrl + alt + shift + L
// 잘라내기 : ctrl + x
// 뒤로가기 : ctrl + z
// 앞으로 가기 : ctrl + y
// 전체 화면 : ctrl + m

public class Key {
	public static void main(String[] args) {
		System.out.print(2);
	}
}
